import java.util.Scanner;
public class funcionesEp4 {

    public static Scanner sc = new Scanner(System.in);

    // Episodio 4
    public static void mostrarEventoCueva() {
        System.out.println("\nTras superar la torre, un portal te transporta a una cueva subterránea.");
        System.out.println("El aire vibra con ecos antiguos y, en el centro, ves tres objetos sobre un altar:");
        System.out.println("- Una pluma dorada");
        System.out.println("- Una piedra brillante");
        System.out.println("- Una llave oxidada");
        System.out.println("\nUna voz te susurra: 'Solo uno de estos te mostrará la salida... elige con sabiduría.'");
    }

    public static void listarObjetos() {
        String[] objetos = {"Una pluma", "Piedra filosa", "Llave extraña"};

        System.out.println("\nObjetos disponibles:");
        for (int i = 0; i < objetos.length; i++) {
            System.out.println((i + 1) + ". " + objetos[i]);
        }
    }

    public static String elegirObjeto(int opcion) {
        String[] objetos = {"Pluma dorada", "Piedra brillante", "Llave oxidada"};

        if (opcion < 1 || opcion > objetos.length) {
            return "Ninguno";
        }
        return objetos[opcion - 1];
    }

    public static boolean evaluarObjeto(String objetoElegido) {
        boolean correcto = false;

        switch (objetoElegido) {
            case "Pluma dorada":
                System.out.println("La pluma se transforma en una luz brillante que ilumina una salida secreta.");
                correcto = true;
                break;
            case "Piedra brillante":
                System.out.println("La piedra se agrieta y se disuelve... No era la elección correcta.");
                break;
            case "Llave oxidada":
                System.out.println("La llave encaja en un cofre vacío. El eco de un suspiro llena la cueva...");
                break;
            default:
                System.out.println("No has elegido nada y la oscuridad te envuelve.");
        }

        return correcto;
    }

    public static boolean episodioCueva() {
        mostrarEventoCueva();
        listarObjetos();

        System.out.print("Elige un objeto (1-3): ");
        int opcion = sc.nextInt();
        sc.nextLine();

        String objetoElegido = elegirObjeto(opcion);
        System.out.println("\nHas elegido: " + objetoElegido);

        boolean salida = evaluarObjeto(objetoElegido);

        if (salida) {
            System.out.println("\nLa voz susurra: 'Has elegido con el corazón correcto... continúa tu viaje.'");
        } else {
            System.out.println("\nEl eco se apaga. Deberás volver a intentarlo...");
        }

        return salida;
    }
}
